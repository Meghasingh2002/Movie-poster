// script.js
let cartItems = [];
const cartCountElement = document.getElementById('cart-count');

function addToCart(productName, price) {
    const item = { productName, price };
    cartItems.push(item);
    updateCartCount();
}

function updateCartCount() {
    cartCountElement.textContent = cartItems.length;
}

document.addEventListener('DOMContentLoaded', function() {
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function() {
            const productName = this.dataset.product;
            const price = parseFloat(this.dataset.price);
            addToCart(productName, price);
        });
    });
});
