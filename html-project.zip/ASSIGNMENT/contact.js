document.addEventListener('DOMContentLoaded', function () {
    const contactForm = document.getElementById('contactForm');
    const successMessage = document.getElementById('successMessage');
  
    contactForm.addEventListener('submit', function (event) {
      event.preventDefault();
  
      // Simulate sending the form data to a server (You can replace this with actual form submission code)
      // In this example, we just show a success message.
      showSuccessMessage();
    });
  
    function showSuccessMessage() {
      successMessage.style.display = 'block';
      contactForm.reset();
  
      // Hide the success message after 3 seconds
      setTimeout(function () {
        successMessage.style.display = 'none';
      }, 3000);
    }
  });
  